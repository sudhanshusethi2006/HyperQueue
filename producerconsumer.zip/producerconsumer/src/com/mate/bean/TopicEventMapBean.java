package com.mate.bean;

import java.util.ArrayList;
import java.util.Map;

public class TopicEventMapBean {
	private Map<String, Topic> TopicEventMap;
	private ArrayList<String> topicist;

	public Map<String, Topic> getTopicEventMap() {
		return TopicEventMap;
	}

	public void setTopicEventMap(Map<String, Topic> topicEventMap) {
		TopicEventMap = topicEventMap;
	}

	public ArrayList<String> getTopicist() {
		return topicist;
	}

	public void setTopicist(ArrayList<String> topicist) {
		this.topicist = topicist;
	}
	
	
}
