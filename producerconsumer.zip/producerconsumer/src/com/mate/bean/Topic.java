package com.mate.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Topic {
    
    private String id;
    private final List<Event> events = Collections.synchronizedList(new ArrayList<Event>());
    
    public Topic(){
    }
    
    public Topic (String id){
        this.id = id;
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public List<Event> getEvents() {
        return events;
    }
    
    public void add(Event event) {
        events.add(event);
    }
    
} 

