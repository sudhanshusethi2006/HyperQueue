package com.meta.controller;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;
import com.mate.bean.Topic;
import com.mate.bean.Event;
import com.mate.bean.TopicEventMapBean;;

@Controller
public class ProducerController {

	public ArrayList<String> topicList = new ArrayList<String>();
	public Map<String, Topic> TopicEventMap = new ConcurrentHashMap<String, Topic>();

	public ProducerController() {
		super();
	}

	@Autowired
	private WebApplicationContext appContext;

	//This method returns the Producer page.It also Displays the User Name and the Session for that User
	@RequestMapping(value = "/producer.htm", method = RequestMethod.GET)
	public ModelAndView viewProducerPage(HttpServletRequest request, HttpServletResponse response) {
		String userId = request.getParameter("userId");
		ModelMap modelMap = new ModelMap();
		HttpSession session = request.getSession();
		if (userId != null && userId.length() > 0) {
			modelMap.addAttribute("userId", userId);
		}
		modelMap.addAttribute("sessionId", session.getId());
		return new ModelAndView("Producer", modelMap);
	}

	// This Method Created the Queue and saves the Topic and its Event Data entered by the User to the Queue. It Displays the Success page if it is saved successfully
	@RequestMapping(value = "/AddTopic.htm", method = RequestMethod.POST)
	public ModelAndView save(HttpServletRequest request, HttpServletResponse response) {

		ModelMap modelMap = new ModelMap();
		String TopicName = request.getParameter("Topic");
		String[] EventNames = request.getParameterValues("EventList[]");
		String userId = request.getParameter("userId");
		if (userId != null && userId.length() > 0) {
			modelMap.addAttribute("userId", userId);
		}
		int size = EventNames.length;
		Topic topic = new Topic(TopicName);
		for (int i = 0; i < size; i++) {
			topic.add(new Event(EventNames[i]));
		}
		TopicEventMap.put(TopicName, topic);
		topicList.add(TopicName);
		TopicEventMapBean TopicEventMapBean = (TopicEventMapBean) appContext.getBean("TopicEventMapBean");
		TopicEventMapBean.setTopicEventMap(TopicEventMap);
		TopicEventMapBean.setTopicist(topicList);
		return new ModelAndView("TopicAdded", modelMap);

	}
}
