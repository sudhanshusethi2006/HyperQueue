package com.meta.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.mate.bean.Event;
import com.mate.bean.Topic;
import com.mate.bean.TopicEventMapBean;

@Controller
public class ConsumerController {
	public ConsumerController() {
		super();
	}

	@Autowired
	private WebApplicationContext appContext;

	// This method returns the consumer page. It also displays the user name, List of Topics and Session Id of the user
	@RequestMapping(value = "/consumer.htm", method = RequestMethod.GET)
	public ModelAndView viewConsumerPage(HttpServletRequest request, HttpServletResponse response) {
		ModelMap modelMap = new ModelMap();
		HttpSession session = request.getSession();
		String userId = request.getParameter("userId");
		modelMap.addAttribute("sessionId", session.getId());
		if (userId != null && userId.length() > 0) {
			modelMap.addAttribute("userId", userId);
		}
		if (((TopicEventMapBean) appContext.getBean("TopicEventMapBean")).getTopicist() != null) {
			TopicEventMapBean TopicEventMapBean = (TopicEventMapBean) appContext.getBean("TopicEventMapBean");

			ArrayList<String> topicListValuefromBean = TopicEventMapBean.getTopicist();
			if (topicListValuefromBean.size() != 0 && topicListValuefromBean.size() > 0) {
				modelMap.addAttribute("TotalTopics", topicListValuefromBean.size());
				modelMap.addAttribute("TopicKeySet", topicListValuefromBean);
			}
		} else {

			modelMap.addAttribute("TotalTopics", 0);
		}
		return new ModelAndView("Consumer", modelMap);
	}

	// This method Displays the List of Events for the Particular Topic of the Queue as selected by the Consumer
	@RequestMapping(value = "/ShowEventList.htm", method = RequestMethod.POST)
	public ModelAndView GetEventDetails(HttpServletRequest request, HttpServletResponse response) {
		ModelMap modelMap = new ModelMap();
		String TopicName = request.getParameter("SelectedTopic");
		if (TopicName == "" || TopicName.length() == 0) {
			modelMap.addAttribute("EventListByTopicName", " please select a Topic to get Events");
		} else {
			modelMap.addAttribute("EventListByTopicName", TopicName);
		}
		System.out.println(TopicName);
		if (((TopicEventMapBean) appContext.getBean("TopicEventMapBean")).getTopicEventMap() != null
				&& ((TopicEventMapBean) appContext.getBean("TopicEventMapBean")).getTopicist() != null) {
			TopicEventMapBean TopicEventMapBean = (TopicEventMapBean) appContext.getBean("TopicEventMapBean");
			Map<String, Topic> topicEventMapValuefromBean = TopicEventMapBean.getTopicEventMap();
			if (topicEventMapValuefromBean != null) {
				if (topicEventMapValuefromBean.containsKey(TopicName)) {
					Topic TopicObj = topicEventMapValuefromBean.get(TopicName);
					List<Event> MyEventList = TopicObj.getEvents();
					if (MyEventList.size() == 0) {
						modelMap.addAttribute("ListOfEvents", "No Events Found");
					} else {
						modelMap.addAttribute("ListOfEvents", MyEventList);

					}

				}
			}

		}
		return new ModelAndView("ShowEventList", modelMap);
	}

}
